let mario;
let foods = [];
let guiaAgrinho;
let score = 0;

// Configurações de tempo e limites
let lastFoodSpawnTime = 0;
const FOOD_SPAWN_INTERVAL = 2000; // Milissegundos entre o surgimento de novos alimentos
const MAX_FOODS_PER_PLOT = 4; // Limite de alimentos por plantação (canteiro)

// Definição das áreas de plantação com coordenadas e tipos
const cornPlot = {
  x: 50,
  y: 350, // Posição Y ajustada para ficar na metade inferior da tela
  width: 380,
  height: 200,
  foodType: 'milho',
  foodsCount: 0 // Para controlar quantos alimentos há neste canteiro
};

const tomatoPlot = {
  x: 470, // Posição X para o segundo canteiro
  y: 350, // Posição Y ajustada
  width: 380,
  height: 200,
  foodType: 'tomate',
  foodsCount: 0 // Para controlar quantos alimentos há neste canteiro
};

const plots = [cornPlot, tomatoPlot]; // Array com todas as plantações

// Diálogos do Guia
const dialogs = [
  "Olá, fazendeiro(a)! Bem-vindo(a) à Fazenda Agrinho!",
  "Use as SETAS para mover o Mario e colher os alimentos.",
  "À esquerda, temos o campo de milho. Vá lá e colha!",
  "À direita, você encontrará o campo de tomates. Estão madurinhos!",
  "Coletar alimentos frescos é um passo importante para a saúde!",
  "Continue colhendo, a fazenda prospera com seu esforço!"
];
let currentDialogIndex = 0;
let dialogBoxShowing = false;
let dialogStartTime = 0;
const DIALOG_DURATION = 5000; // Duração de cada diálogo em milissegundos (5 segundos)

function setup() {
  createCanvas(900, 600);
  mario = new Mario(width / 4, height - 80); // Posição inicial do Mario
  guiaAgrinho = new Guia(width - 200, height * 0.1); // Posição do guia na casa

  // Inicia o primeiro diálogo
  showDialog(dialogs[currentDialogIndex]);
}

function draw() {
  drawFarmBackground(); // Desenha o fundo da fazenda (céu e nuvens)
  drawGround(); // Desenha o chão marrom
  drawPlots(); // Desenha as áreas de plantação separadas

  drawGuiaHouse(); // Desenha a casa do guia
  guiaAgrinho.display(); // Desenha o Guia

  mario.update();
  mario.display();

  // Gerar novos alimentos dentro das plantações
  if (millis() - lastFoodSpawnTime > FOOD_SPAWN_INTERVAL) {
    spawnFoodInPlots();
    lastFoodSpawnTime = millis();
  }

  // Desenhar e verificar alimentos
  for (let i = foods.length - 1; i >= 0; i--) {
    let food = foods[i];
    food.display();

    // Colisão para coleta
    let d = dist(mario.x + mario.width / 2, mario.y + mario.height / 2, food.x + food.size / 2, food.y + food.size / 2);
    if (d < (mario.width / 2 + food.size / 2) * 0.7) {
      // Remove o alimento
      foods.splice(i, 1);
      score += 1; // Aumenta a pontuação

      // Reduz a contagem de alimentos no canteiro correspondente
      if (food.type === 'milho') {
        cornPlot.foodsCount--;
      } else if (food.type === 'tomate') {
        tomatoPlot.foodsCount--;
      }

      // Dicas adicionais baseadas na pontuação
      if (score === 3) {
        showDialog("Ótimo começo! Continue colhendo para aprender mais!");
      } else if (score === 8) {
        showDialog("Você é um(a) fazendeiro(a) muito eficiente! Parabéns!");
      }
    }
  }

  // Exibir pontuação
  fill(255); // Texto branco
  noStroke();
  textSize(28);
  text("Alimentos Coletados: " + score, 20, 40);

  // Gerenciar e exibir diálogo do Guia
  if (dialogBoxShowing) {
    drawDialogBox();
    if (millis() - dialogStartTime > DIALOG_DURATION) {
      dialogBoxShowing = false;
      // Avança para o próximo diálogo na sequência se não houver um diálogo específico
      if (currentDialogIndex < dialogs.length - 1) {
        currentDialogIndex++;
      } else {
        currentDialogIndex = 0; // Volta ao início dos diálogos
      }
      // Inicia o próximo diálogo após um pequeno atraso
      setTimeout(() => {
        showDialog(dialogs[currentDialogIndex]);
      }, 3000); // 3 segundos antes do próximo diálogo automático
    }
  }

  drawMarioBasket(); // Desenha a cesta do Mario
}

// --- Funções de Desenho de Cena ---
function drawFarmBackground() {
  background(135, 206, 235); // Céu azul claro
  // Nuvens
  fill(255, 255, 255, 200);
  ellipse(width * 0.2, height * 0.1, 80, 40);
  ellipse(width * 0.35, height * 0.15, 100, 50);
  ellipse(width * 0.7, height * 0.1, 90, 45);
  ellipse(width * 0.85, height * 0.18, 70, 35);
}

function drawGround() {
  fill(139, 69, 19); // Marrom para o chão
  noStroke();
  rect(0, height * 0.5, width, height * 0.5); // Metade inferior da tela
}

function drawPlots() {
  // Desenha os canteiros de plantação
  fill(100, 70, 0); // Cor mais escura para a terra dos canteiros
  stroke(50, 30, 0); // Borda escura
  strokeWeight(3);

  // Canteiro de Milho
  rect(cornPlot.x, cornPlot.y, cornPlot.width, cornPlot.height, 10);
  fill(255); // Texto branco
  noStroke();
  textSize(18);
  textAlign(CENTER, CENTER);
  text("CAMPO DE MILHO", cornPlot.x + cornPlot.width / 2, cornPlot.y + cornPlot.height + 25);

  // Canteiro de Tomate
  fill(100, 70, 0);
  stroke(50, 30, 0);
  rect(tomatoPlot.x, tomatoPlot.y, tomatoPlot.width, tomatoPlot.height, 10);
  fill(255);
  noStroke();
  text("CAMPO DE TOMATE", tomatoPlot.x + tomatoPlot.width / 2, tomatoPlot.y + tomatoPlot.height + 25);

  noStroke(); // Reset stroke
  textAlign(LEFT, BASELINE); // Volta ao alinhamento padrão
}

function drawGuiaHouse() {
  fill(150, 100, 50); // Cor da parede da casa
  rect(guiaAgrinho.houseX, guiaAgrinho.houseY, 150, 150); // Corpo da casa
  fill(180, 0, 0); // Cor do telhado
  triangle(guiaAgrinho.houseX - 20, guiaAgrinho.houseY,
    guiaAgrinho.houseX + 150 + 20, guiaAgrinho.houseY,
    guiaAgrinho.houseX + 150 / 2, guiaAgrinho.houseY - 80); // Telhado triangular
  fill(100); // Cor da porta
  rect(guiaAgrinho.houseX + 60, guiaAgrinho.houseY + 80, 30, 70); // Porta
  fill(200, 200, 200); // Cor da janela
  rect(guiaAgrinho.houseX + 20, guiaAgrinho.houseY + 30, 30, 30); // Janela
}

function drawDialogBox() {
  fill(255, 255, 200, 220); // Caixa de diálogo amarela clara, semi-transparente
  stroke(100, 70, 0); // Borda marrom
  strokeWeight(2);
  rect(width - 420, 10, 400, 100, 10); // Posição e tamanho da caixa
  fill(0); // Cor do texto
  noStroke();
  textSize(16);
  textWrap(WORD);
  text(dialogs[currentDialogIndex], width - 400, 30, 380);
}

function showDialog(message) {
  // Encontra o índice da mensagem para garantir que seja a que está no array de diálogos
  let index = dialogs.indexOf(message);
  if (index !== -1) {
    currentDialogIndex = index;
  } else {
    // Se a mensagem não estiver no array padrão, adiciona ela temporariamente no currentDialogIndex
    dialogs[currentDialogIndex] = message;
  }
  dialogBoxShowing = true;
  dialogStartTime = millis();
}


// --- Classe Mario (Fazendeiro) ---
class Mario {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 45;
    this.height = 70;
    this.speed = 4;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }

    // Limitar o Mario à área do chão (abaixo da metade da tela)
    this.x = constrain(this.x, 0, width - this.width);
    this.y = constrain(this.y, height * 0.5, height - this.height);
  }

  display() {
    // Desenho do Mario
    // Chapéu
    fill(200, 0, 0); // Vermelho Mario
    rect(this.x + this.width * 0.1, this.y, this.width * 0.8, this.height * 0.2, 5);
    ellipse(this.x + this.width / 2, this.y + this.height * 0.1, this.width * 0.7, this.height * 0.2);

    // Cabeça
    fill(255, 220, 180); // Cor da pele
    ellipse(this.x + this.width / 2, this.y + this.height * 0.25, this.width * 0.7, this.height * 0.3);

    // Bigode
    fill(50); // Preto
    rect(this.x + this.width * 0.25, this.y + this.height * 0.35, this.width * 0.5, this.height * 0.08);

    // Olhos
    fill(255);
    ellipse(this.x + this.width * 0.35, this.y + this.height * 0.25, 5, 5);
    ellipse(this.x + this.width * 0.65, this.y + this.height * 0.25, 5, 5);

    // Corpo (Macacão azul e camisa vermelha)
    fill(0, 0, 150); // Azul (macacão)
    rect(this.x, this.y + this.height * 0.4, this.width, this.height * 0.6);

    fill(200, 0, 0); // Vermelho (camisa)
    rect(this.x + this.width * 0.1, this.y + this.height * 0.4, this.width * 0.8, this.height * 0.3);

    // Botões
    fill(255);
    ellipse(this.x + this.width * 0.3, this.y + this.height * 0.55, 5, 5);
    ellipse(this.x + this.width * 0.7, this.y + this.height * 0.55, 5, 5);

    // Sapatos
    fill(90, 60, 30);
    rect(this.x + this.width * 0.1, this.y + this.height * 0.9, this.width * 0.3, this.height * 0.1);
    rect(this.x + this.width * 0.6, this.y + this.height * 0.9, this.width * 0.3, this.height * 0.1);
  }
}

function drawMarioBasket() {
  let basketX = mario.x + mario.width * 0.7;
  let basketY = mario.y + mario.height * 0.6;
  let basketW = 35;
  let basketH = 30;

  fill(160, 82, 45); // Marrom para a cesta
  rect(basketX, basketY, basketW, basketH, 5);
  noFill();
  stroke(120, 60, 30);
  strokeWeight(2);
  arc(basketX + basketW / 2, basketY, basketW * 0.8, basketH * 0.8, PI, TWO_PI);
  noStroke();
}

// --- Classe Guia do Agrinho ---
class Guia {
  constructor(x, y) {
    this.houseX = x;
    this.houseY = y;
    this.x = x + 70; // Posição do guia dentro da casa
    this.y = y + 80;
    this.width = 40;
    this.height = 60;
  }

  display() {
    // Desenhar o Guia
    fill(255, 220, 180); // Cor da pele
    ellipse(this.x + this.width / 2, this.y + this.height * 0.2, this.width * 0.8, this.height * 0.4);

    fill(0); // Olhos
    ellipse(this.x + this.width * 0.3, this.y + this.height * 0.15, 5, 5);
    ellipse(this.x + this.width * 0.7, this.y + this.height * 0.15, 5, 5);

    noFill(); // Boca
    stroke(0);
    arc(this.x + this.width / 2, this.y + this.height * 0.3, 15, 10, 0, PI);
    noStroke();

    fill(180, 160, 90); // Chapéu de fazendeiro
    rect(this.x + this.width * 0.1, this.y, this.width * 0.8, this.height * 0.1, 3);
    ellipse(this.x + this.width / 2, this.y + this.height * 0.05, this.width * 0.6, this.height * 0.1);

    fill(70, 130, 180); // Corpo - Camiseta
    rect(this.x + this.width * 0.1, this.y + this.height * 0.4, this.width * 0.8, this.height * 0.4);
    fill(80, 80, 80); // Corpo - Calça
    rect(this.x + this.width * 0.2, this.y + this.height * 0.8, this.width * 0.6, this.height * 0.2);
  }
}

// --- Classe Alimento ---
class Food {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.size = 30; // Tamanho base do alimento
    this.type = type; // 'milho' ou 'tomate'
  }

  display() {
    if (this.type === 'milho') {
      fill(255, 255, 0); // Amarelo
      ellipse(this.x + this.size / 2, this.y + this.size / 2, this.size * 0.7, this.size * 1.2);
      fill(50, 150, 50); // Verde para as folhas
      triangle(this.x + this.size * 0.1, this.y + this.size * 0.3, this.x + this.size * 0.5, this.y - this.size * 0.1, this.x + this.size * 0.7, this.y + this.size * 0.4);
      triangle(this.x + this.size * 0.9, this.y + this.size * 0.3, this.x + this.size * 0.5, this.y - this.size * 0.1, this.x + this.size * 0.3, this.y + this.size * 0.4);

    } else if (this.type === 'tomate') {
      fill(200, 0, 0); // Vermelho
      ellipse(this.x + this.size / 2, this.y + this.size / 2, this.size, this.size);
      fill(50, 150, 50); // Verde para o talo
      rect(this.x + this.size / 2 - 2, this.y + this.size * 0.1, 4, 10);
    }
  }
}

// --- Funções Auxiliares de Jogo ---
function spawnFoodInPlots() {
  plots.forEach(plot => {
    // Verifica quantos alimentos já existem neste canteiro específico
    // Filtra `foods` para contar apenas os alimentos do tipo e dentro das coordenadas do `plot`
    let foodsInPlot = foods.filter(f =>
      f.type === plot.foodType &&
      f.x >= plot.x && f.x <= plot.x + plot.width - f.size &&
      f.y >= plot.y && f.y <= plot.y + plot.height - f.size
    ).length;

    if (foodsInPlot < MAX_FOODS_PER_PLOT) {
      // Gera uma posição aleatória dentro dos limites do canteiro
      let randX = random(plot.x + 10, plot.x + plot.width - 10 - 30); // 30 = tamanho do alimento
      let randY = random(plot.y + 10, plot.y + plot.height - 10 - 30);
      foods.push(new Food(randX, randY, plot.foodType));
      // Aumenta a contagem para o canteiro (controle interno)
      plot.foodsCount++;
    }
  });
}